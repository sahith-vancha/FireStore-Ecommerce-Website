
<?php

session_start();


?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="productPage.css" rel="stylesheet"/>
    <title>Product Page</title>
  </head>
  <body>
    <header class="titleHeader">
      <div class="container">
        <div class="navbar">
          <div id="companyLogo"> <!--site logo-->
            <img src="img/Icons/logo.png">
          </div>	
          <nav> <!--navigation area -->
            <ul class="topNav" id="myTopNav">
              <li><a href="homepage.php">HOME</a></li>
              <li class="current"><a href="productPage.php">PRODUCTS</a></li>
              <?php
                if (isset($_SESSION["userid"])) {
                  echo "<li><a href='logout.php'>LOGOUT</a></li>";
                }
                else {
                  echo "<li><a href='login.php'>LOGIN/REGISTER</a></li>";
                }
              ?>
              <li><img src="img/Icons/navbars.png" width="20" height="20" onclick="menuToggle()" class="icon"></li>
              <div id="myCart">
                <img src="img/shopping-cart-of-checkered-design.png" class="cartButton" id="cartButtonMobile" onclick="openCart()"></img>
                <div id="cartSection">
                  <button class="closebtn" onclick="closeCart()">Close</button>
                  <h2 id="cartID">Cart</h2>
                  <div id="totalCSS"></div>
                  <p id="totalSign">Total: $</p>
                  <p id= "total">0</p>
                  <button id="checkout" onclick="checkout()">Proceed to Checkout</button>
                  <form action="cart.php" method="post">
                    <input type="text" id="totalcartz" name="cartTotal">
                    <button type="submit" name="submit">Confirm Cart and Proceed to Checkout</button>
                  </form> 
                </div>
                
              </div>
            </ul>
          </nav>
        </div>
      </div>
  </header>



    <ul id="productGroup">
    
      <article class="product">
        
        <li>
          <h2 class= "productName">Puma BaseBall Cap</h2>
          <img src="img/Baseball Cap1.jpg" width="250" height="250" alt="alt text" /img>
        <p>
          Flexible-Fit and durable cap 
        </p>
        <p id="productPrice" int= 70><strong>$35.00</strong></p>
      </li>
      <p>
      <select name="color" id="color">
        <option>blue</option>
        <option>black</option>
      </select>
      <select name="gender" id="gender">
        <option>M</option>
        <option>F</option>
      </select>
      <select name="size" id="size">
        <option >S</option>
        <option >M</option>
        <option >L</option>
      </select>
    </p>
        <button onclick="addItem(0, 35)" class="addToCart">Add to cart</button>
      </article>
     
      <article class="product">
        
        <li>
          
        <h2 class= "productName">Fila Running Shoes</h2>
        <img src="img/whitefila.jpg" width="250" height="250" alt="alt text" /img>
        <p>
          Light-weight for all activites 
        </p>
        <p id="productPrice" int= 70><strong>$52.00</strong></p>
      </li>
      <p>
      <select name="color" id="color">
        <option>white</option>
        <option>pink</option>
        <option>black</option>
      </select>
      <select name="gender" id="gender">
        <option>M</option>
        <option>F</option>
      </select>
      <select name="size" id="size">
        <option >S</option>
        <option >M</option>
        <option >L</option>
      </select>
    </p>

  
        <button onclick="addItem(1, 52)" class="addToCart">Add to cart</button>
      </article>

      <article class="product">
        
        <li>
        <h2 class= "productName">Adidas Track Pants</h2>
        <img src="img/trackpantsmaroon.jpg" width="180" height="250" alt="alt text" /img> 
        <p>
          Made with Flex-Move technology 
        </p>
        <p id="productPrice" int= 70><strong>$73.00</strong></p>
      </li>
      <p>
      <select name="color" id="color">
        <option>maroon</option>
        <option>mint</option>
        <option>blue</option>
      </select>
      <select name="gender" id="gender">
        <option>M</option>
        <option>F</option>
      </select>
      <select name="size" id="size">
        <option >S</option>
        <option >M</option>
        <option >L</option>
      </select>
    </p>

        <button onclick="addItem(2, 73)" class="addToCart">Add to cart</button>
      </article>

        
      <article class="product">
        
        <li>
        <h2 class= "productName">Nike Sports shirt</h2>
        <img src="img/tshirtGreen.jpg" width="180" height="250" alt="alt text" /img>
        <p>
          Anti-Sweat fabric 
        </p>
        <p id="productPrice" int= 70><strong>$25.00</strong></p>
      </li>
      <p>
      <select name="color" id="color">
        <option>green</option>
        <option>blue</option>
      </select>
      <select name="gender" id="gender">
        <option>M</option>
        <option>F</option>
      </select>
      <select name="size" id="size">
        <option >S</option>
        <option >M</option>
        <option >L</option>
      </select>
    </p>
        <button onclick="addItem(3, 25)" class="addToCart">Add to cart</button>
      </article>

      <article class="product">
        
        <li>
        <h2 class= "productName">Adidas Socks</h2>
        <img src="img/Socks.jpg" width="200" height="250" alt="alt text" /img>
        <p>
          General athletic socks 
        </p>
        <p id="productPrice" int= 70><strong>$15.00</strong></p>
      </li>
      <p>
      <select name="color" id="color">
        <option>white</option>
        <option>black</option>
      </select>
      <select name="gender" id="gender">
        <option>M</option>
        <option>F</option>
      </select>
      <select name="size" id="size">
        <option >S</option>
        <option >M</option>
        <option >L</option>
      </select>
    </p>
        <button onclick="addItem(4, 15)" class="addToCart">Add to cart</button>
      </article>

      
      <article class="product">
        
        <li>
        <h2 class= "productName">Nike Sports Shorts</h2>
        <img src="img/shortsblack.jpg" width="200" height="250" alt="alt text" /img>
        <p>
          Flex-move technology 
        </p>
        <p id="productPrice" int= 70><strong>$25.00</strong></p>
      </li>
      <p>
      <select name="color" id="color">
        <option>black</option>
        <option>green</option>
      </select>
      <select name="gender" id="gender">
        <option>M</option>
        <option>F</option>
      </select>
      <select name="size" id="size">
        <option >S</option>
        <option >M</option>
        <option >L</option>
      </select>
    </p>
        <button onclick="addItem(5, 25)" class="addToCart">Add to cart</button>
      </article>
    </ul>


    <div class="footer">
      <div class="logomessage">
        <img src="img/Icons/logo.png">
        <p>Copyright 2022</p>
      </div>
      <div class="contact">
        <h3>Questions or Comments?</h3><br>
        <p>Call us at 770-365-4522</p><br>
        <p>Email us at FireStoreSupport@gmail.com</p>
      </div>
    </div>

    <script src="productPage.js">
    </script>
    	<script>
        function menuToggle() {
          var x = document.getElementById("myTopNav");
          if (x.className === "topnav") {
            x.className += " responsiveNav";
          }
          else {
            x.className = "topnav";
          }
    
        }
      </script>
   </body>
</html>
