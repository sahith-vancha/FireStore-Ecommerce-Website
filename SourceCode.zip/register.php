<?php

if(isset($_POST["submit"])) {
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$username = $_POST['username_new'];
	$password = $_POST['password_new'];

	require_once 'connection.php';
	require_once 'functions.php';

	if (emptyUserInput($fname, $lname, $username, $password) !== false) {
		header("location: login.php?error=emptyinput");
		exit();

	}

	if (userExists($conn, $username) !== false) {
		header("location: login.php?error=usertaken");
		exit();
	}

	createUser($conn, $fname, $lname, $username, $password);

}

else {
	header("location: login.php");
	exit();
}






/*
if (empty($_POST["fname"])) {
	die("Please enter your first name");
}

if (empty($_POST["lname"])) {
	die("Please enter your last name");
}

if (empty($_POST["username_new"])) {
	die("Please enter a username");
}

if (empty($_POST["password_new"])) {
	die("Please enter a password");
}
*/
/*$mysqli = require __DIR__ . "/connection.php";

$sql = "INSERT INTO registration (fname, lname, username_new, password_new) VALUES (?, ?, ?, ?)";

$stmt = $mysqli->stmt_init();

if ( ! $stmt->prepare($sql)) {
	die("SQL error");
}

$stmt->bind_param("ssss", $_POST["fname"], $_POST["lname"], $_POST["username_new"], $_POST["password_new"]);

$stmt->execute();

echo "Signup Success";*/ 
/*
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$username = $_POST['username_new'];
$password = $_POST['password_new'];




$conn = mysqli_connect('localhost','root','','test');
	
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		//Use prepared statement to execute the same (or similar) SQL statements repeatedly with high efficiency.
		//The SQL statement template is created and sent to the database. Some values are left unspecified (i.e., ?) parameters
		$query = "select * from registration where username_new = '$username' limit 1";
		$result = mysqli_query($conn, $query);
		if(mysqli_num_rows($result) > 0) {
			die("user already exists!");
		}
		else {
			$stmt = $conn->prepare("insert into registration(fname, lname, username_new, password_new) values(?,?,?,?)");
			//Bind the values to parameters
			//s represents String
			//i - integer
			//d - double
        	//s - string
			$stmt->bind_param("ssss", $fname, $lname, $username, $password);
			//execute the SQL statement
			$execval = $stmt->execute();
		
			if ($execval) {
				header("Location: login.html");
				echo "<script>alert('good job')</script>";
			}
			else {
				die($conn->error . " " . $conn->errno);
			}
			$stmt->close();
			$conn->close();
		}
	} */


