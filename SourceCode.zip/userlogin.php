<?php

if(isset($_POST["submit"])) {
	//$fname = $_POST['fname'];
	//$lname = $_POST['lname'];
	$user = $_POST['username'];
	$pass = $_POST['password'];

	require_once 'connection.php';
	require_once 'functions.php';

	if (emptyLoginInput($user, $pass) !== false) {
		header("location: login.php?error=emptyinput");
		exit();
	}

	loginUser($conn, $user, $pass);
}

else {
	header("location: login.php");
	exit();
}