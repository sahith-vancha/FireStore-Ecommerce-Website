<?php

session_start();


if(isset($_POST["submit"]) && isset($_SESSION["userid"])) {
	$TotalAmount = $_POST['cartTotal'];
	$customer = $_SESSION['userid'];

	require_once 'connection.php';
	require_once 'functions.php';

	createCart($conn, $TotalAmount, $customer);

}

else {
	header("location: login.php?error=cartErrorPleaseLogin");
	exit();
}


