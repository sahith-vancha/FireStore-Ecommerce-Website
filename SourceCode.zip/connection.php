<?php

$host = "localhost";
$dbname = "test";
$dbusername = "root";
$dbpassword = "";

$conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);

if (!$conn) {
	die("Connection Failed: " . mysqli_connect_error());
}