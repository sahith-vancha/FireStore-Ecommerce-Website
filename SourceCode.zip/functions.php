<?php

function emptyUserInput($fname, $lname, $username, $password) {
	$result;
	if (empty($fname) || empty($lname) || empty($username) || empty($password)) {
		$result = true; 
	}
	else {
		$result = false; 
	}

	return $result;

}

function userExists($conn, $username) {
	$sql = "SELECT * FROM registration WHERE username_new = ?;";
	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $sql)) {
		header("location: login.php?error=stmtfailed");
		exit();
	}

	mysqli_stmt_bind_param($stmt, "s", $username);
	mysqli_stmt_execute($stmt);
	$resultData = mysqli_stmt_get_result($stmt);

	if ($row = mysqli_fetch_assoc($resultData)) {
		return $row;
	}
	else {
		$result = false;
		return $result;
	}

	mysqli_stmt_close($stmt);

}

function createUser($conn, $fname, $lname, $username, $password) {
	$sql = "INSERT INTO registration (fname, lname, username_new, password_new) VALUES (?,?,?,?);";
	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $sql)) {
		header("location: login.php?error=stmtfailed");
		exit();
	}

	mysqli_stmt_bind_param($stmt, "ssss", $fname, $lname, $username, $password);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_close($stmt);

	header("location: login.php?error=none");
	exit();

}

function emptyLoginInput($user, $pass) {
	$result;
	if (empty($user) || empty($pass)) {
		$result = true; 
	}
	else {
		$result = false; 
	}

	return $result;

}

function loginUser($conn, $user, $pass) {
	$doesUserExist = userExists($conn, $user);

	if ($doesUserExist === false) {
		header("location: login.php?error=wrongloginuserexistsnot");
		exit();
	}

	$dbPass = $doesUserExist["password_new"];
	//$checkPass = password_verify($pass, $dbPass);

	if ($dbPass !== $pass) {
		header("location: login.php?error=wronglogin");
		exit();
	}

	else if ($dbPass === $pass) {
		session_start();
		$_SESSION["userid"] = $doesUserExist["username_new"];
		header("location: homepage.php");
		exit();
	}
}

function createCart($conn, $cartAmount, $user) {
	$sql = "INSERT INTO cart (userID, OrderTotal) VALUES (?,?);";
	$stmt = mysqli_stmt_init($conn);
	if (!mysqli_stmt_prepare($stmt, $sql)) {
		header("location: productPage.php?error=CartFailedRetry");
		exit();
	}

	mysqli_stmt_bind_param($stmt, "ss", $user, $cartAmount);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_close($stmt);
	exit();

}

function completeOrder(   ) {

	
}