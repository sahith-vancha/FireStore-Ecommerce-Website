<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>    
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="card mt-5">
                    <div class="card-header text-center">
                        <h4>Search Data</h4>
                    </div>
                    <div class="card-body">

                        <form action="" method="GET">
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" name="name" placeholder="Enter name to search" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary">Search</button>
                                </div>
                            </div>
                        </form>

                       <br/><br/>
                       <!-- Display results in a formatted table-->
                        <h3><u>Search Result</u></h3><br/>
                            <div class="table-responsive">          
                              <table class="table">
                                <thead>
                                  <tr>                               
                                    <th>Employee ID</th>
                                    <th>First Name</th>
                                    <th>Second Name</th>
                                    <th>Title</th>
                                  </tr>
                                </thead>
                                <tbody>
                                <?php 
                                    $con = mysqli_connect("localhost","root","","test");
                                    if(isset($_GET['name'])){
                                        $name = $_GET['name'];
                                        $query = "SELECT * FROM employee WHERE first_name='$name' ";
                                        $query_run = mysqli_query($con, $query);
                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $row)
                                            {
                                                ?>
                                                <!-- Insert records in each HTML table-->
                                                <!-- Read and display records by php code-->
                                                <tr>
                                                    <td><?php echo $row['id'];?></td>
                                                    <td><?php echo $row['first_name'];?></td>
                                                    <td><?php echo $row['last_name'];?></td>
                                                    <td><?php echo $row['title'];?></td>
                                                </tr>                         
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            echo "No Record";
                                        }
                                    }                                                                   
                                ?>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>