<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>    
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="card mt-5">
                    <div class="card-header text-center">
                        <h4>Search Data</h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="GET">
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" name="name" placeholder="Enter name to search" class="form-control">
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary">Search</button>
                                </div>
                            </div>
                        </form>

                        <div class="row">
                            <div class="col-md-12">
                                <hr>
                                <!-- Write PHP and SQL code inside HTML to search database and display records-->
                                <?php 
                                    $con = mysqli_connect("localhost","root","","test");
                                    if(isset($_GET['name'])){
                                        //read the input data using "GET"
                                        $name = $_GET['name'];
                                        //Search data by matched name
                                        $query = "SELECT * FROM employee WHERE first_name='$name' ";
                                        $query_run = mysqli_query($con, $query);
                                        
                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            // Display each record
                                            foreach($query_run as $row)
                                            {
                                                echo $row['id']; 
                                                echo $row['first_name']; 
                                                echo $row['last_name']; 
                                                echo $row['title'];
                                            }
                                        }
                                        else
                                        {
                                            echo "No Record";
                                        }
                                    }                                                                   
                                ?>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>