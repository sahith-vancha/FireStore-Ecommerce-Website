<?php
	//Create a PHP session 
    //Will store certain variables to the global variable: $_SESSION
	session_start();
	
	//Connect the database
	$con = mysqli_connect("localhost","root","","test");
	if (mysqli_connect_errno()){
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	

    //Use POST to read data from HTML "Buy now" form
	if (isset($_POST['code']) && $_POST['code']!=""){
		$code = $_POST['code'];
		$result = mysqli_query($con,"SELECT * FROM `products` WHERE `code`='$code'");
		$row = mysqli_fetch_assoc($result);
		$name = $row['name'];
		$code = $row['code'];
		$price = $row['price'];

		//put the information in an array with the quantity
		$cartArray = array(
			$code=>array(
				'name'=>$name,
				'code'=>$code,
				'price'=>$price,
				'quantity'=>1
			)
		);

		$status="";
		
		if(empty($_SESSION["shopping_cart"])) {
			//Store the products in cart to the global $_SESSION variable
			$_SESSION["shopping_cart"] = $cartArray;
			$status = "<div class='box'>Product is added to your cart!</div>";
		}else{
			//update the global $_SESSION variable (products in the cart)
			$_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
			$status = "<div class='box'>Product is added to your cart!</div>";
			}		
	}
?>
<html>
	<head>
		<title>Shopping cart example</title>
			<link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
	</head>
	
	<body>
		<div style="width:700px; margin:50 auto;">
		<h2>Shopping Cart Example</h2>   
		
		<!-- Read from database and display products -->
		<?php
			$result = mysqli_query($con,"SELECT * FROM products");
			while($row = mysqli_fetch_assoc($result)){
				echo "<div class='product_wrapper'>
					  <form method='post' action=''>
						  <input type='hidden' name='code' value=".$row['code']." />
						  <div class='name'>".$row['name']."</div>
					   	  <div class='price'>$".$row['price']."</div>
						  <button type='submit' class='buy'>Buy Now</button>
					  </form>
				   	  </div>";
		    }
			mysqli_close($con);
		?>
		
		
		<!--Get the number of products in the shopping cart-->
		<?php
			$cart_count = count(array_keys($_SESSION["shopping_cart"]));
		?>
	  	<!-- Display the number of products in the shopping cart-->
	  	<!-- linke cart.php by clicking cart to change quantities and get total proce-->
	    <div class="cart_div">
			<a href="cart.php"><img src="cart-icon.png" /> Cart<span><?php echo $cart_count; ?></span></a>
		</div>

		<div style="clear:both;"></div>
		<div class="message_box" style="margin:10px 0px;">
		<?php echo $status; ?>
		</div>
		</div>
	</body>
</html>